﻿using UnityEngine;
using System.Collections;

public class ObstacleScript : MonoBehaviour {

	// define the radius of the block
	private float radius = 2.4f;

	// accessor for the radius
	public float Radius {
		get { return radius; }
	}
}

	